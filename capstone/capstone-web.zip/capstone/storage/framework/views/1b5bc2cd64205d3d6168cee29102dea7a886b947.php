<?php
    
 function goto_caution($msg, $url)
    {
        $str = "<script>";
        $str .= "alert('{$msg}');";
        $str .= "location.href = '{$url}';";
        $str .= "</script>";
        echo("$str");
        exit;
    }

        goto_caution("게시글 작성 완료","/question_board");
?>
<?php /**PATH /var/www/html/capstone/resources/views/question_write_ok.blade.php ENDPATH**/ ?>