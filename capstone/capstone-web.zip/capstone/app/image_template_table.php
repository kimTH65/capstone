<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class image_template_table extends Model
{
    //
}
