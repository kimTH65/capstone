<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class q_reply extends Model
{
    //
}
